#!/data/data/com.termux/files/usr/bin/bash
echo "--- Mukh IDE Configuration (v40.0) ---"
CONFIG_FILE="$HOME/.manus_global_config.json"
read -p "Enter your Telegram Bot Token: " TELEGRAM_TOKEN
read -p "Enter your Telegram Chat ID: " CHAT_ID
if ! gh auth status >/dev/null 2>&1; then
    echo "⚠️ GitHub CLI not configured. Please log in."
    gh auth login
fi
GITHUB_USERNAME=$(gh api user --jq .login)
echo "GitHub Username detected: $GITHUB_USERNAME"
cat > "$CONFIG_FILE" << EOF
{
  "telegram_bot_token": "$TELEGRAM_TOKEN",
  "telegram_chat_id": "$CHAT_ID",
  "github_username": "$GITHUB_USERNAME"
}
EOF
echo "✅ Configuration saved."
