#!/data/data/com.termux/files/usr/bin/bash
# Mukh IDE Smart Configuration (v26.0)

CONFIG_FILE="$HOME/.manus_global_config.json"
echo "--- Mukh IDE Configuration ---"

# --- Helper function to read input with a default value ---
prompt_with_default() {
    local prompt_text="$1"
    local var_name="$2"
    local default_value="$3"
    local value
    
    if [ -n "$default_value" ]; then
        read -p "$prompt_text [Press Enter to use: $default_value]: " value
        # If user just presses Enter, use the default value
        value=${value:-$default_value}
    else
        # Loop until a non-empty value is provided
        while true; do
            read -p "$prompt_text: " value
            if [ -n "$value" ]; then
                break
            else
                echo "This field cannot be empty. Please try again."
            fi
        done
    fi
    # Assign the final value to the variable name passed as argument
    eval "$var_name='$value'"
}

# --- Main Logic ---
OLD_TOKEN=""
OLD_CHAT_ID=""
OLD_GITHUB_USER=""

if [ -f "$CONFIG_FILE" ]; then
    echo "✅ Found existing configuration file. Loading values..."
    # Extract old values safely. If not found, they remain empty.
    OLD_TOKEN=$(grep -o '"telegram_bot_token": "[^"]*' "$CONFIG_FILE" | grep -o '[^"]*$' || echo "")
    OLD_CHAT_ID=$(grep -o '"telegram_chat_id": "[^"]*' "$CONFIG_FILE" | grep -o '[^"]*$' || echo "")
    OLD_GITHUB_USER=$(grep -o '"github_username": "[^"]*' "$CONFIG_FILE" | grep -o '[^"]*$' || echo "")
fi

echo "Please confirm or enter your details:"
prompt_with_default "Enter your Telegram Bot Token" FINAL_TOKEN "$OLD_TOKEN"
prompt_with_default "Enter your Telegram Chat ID" FINAL_CHAT_ID "$OLD_CHAT_ID"
prompt_with_default "Enter your GitHub Username" FINAL_GITHUB_USER "$OLD_GITHUB_USER"

# --- Save the final configuration ---
cat > "$CONFIG_FILE" << EOF
{
  "telegram_bot_token": "$FINAL_TOKEN",
  "telegram_chat_id": "$FINAL_CHAT_ID",
  "github_username": "$FINAL_GITHUB_USER"
}
EOF

echo "✅ Configuration saved successfully to $CONFIG_FILE"
