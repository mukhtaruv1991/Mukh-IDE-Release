#!/data/data/com.termux/files/usr/bin/bash
echo "✅ Configuration script ran successfully."
