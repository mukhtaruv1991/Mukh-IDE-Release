# Mukh Bot (v24.0 - The Final Import System)
import logging, os, json, asyncio, subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# --- Setup ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
HOME_DIR = os.path.expanduser("~")
TOKEN, CHAT_ID, GITHUB_USERNAME = None, None, None
try:
    with open(os.path.join(HOME_DIR, ".manus_global_config.json")) as f:
        config = json.load(f)
    TOKEN = config.get("telegram_bot_token")
    CHAT_ID = config.get("telegram_chat_id")
    GITHUB_USERNAME = config.get("github_username")
except: pass

# --- Helper Functions ---
def run_core_command(command):
    try:
        full_command = f"bash {os.path.expanduser('~/Mukh-IDE/manus-core')} {command}"
        result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=600)
        return result.stdout.strip()
    except Exception as e: return f"Error: {e}"

# --- UI Generation ---
def get_main_menu():
    keyboard = [
        [InlineKeyboardButton("📂 مشاريع مساحة العمل", callback_data='list_workspace_projects')],
        [InlineKeyboardButton("➕ استيراد مشروع جديد", callback_data='import_start')]
    ]
    return InlineKeyboardMarkup(keyboard), "🤖 *Mukh IDE (v24.0)*\n\nاختر إجراءً للبدء."

def get_project_dashboard_menu(project_name):
    project_path = os.path.join(HOME_DIR, "Mukh-IDE", "projects", project_name)
    is_git_repo = os.path.isdir(os.path.join(project_path, ".git"))
    keyboard = []
    if is_git_repo: keyboard.append([InlineKeyboardButton("🚀 نشر", callback_data=f'publish_{project_name}')])
    else: keyboard.append([InlineKeyboardButton("🔗 إعداد GitHub", callback_data=f'setup_github_{project_name}')])
    keyboard.extend([
        [InlineKeyboardButton("📦 تصدير", callback_data=f'export_{project_name}'), InlineKeyboardButton("🛡️ نسخ احتياطي", callback_data=f'backup_{project_name}')],
        [InlineKeyboardButton("🔙 العودة للمشاريع", callback_data='list_workspace_projects')]
    ])
    return InlineKeyboardMarkup(keyboard), f"🛠️ *مشروع: {project_name}*\n\nاختر الإجراء."

# --- Main Bot Logic ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    command = query.data
    context.user_data.pop('state', None)

    if command == 'main_menu':
        await start(update.effective_message, context)
        return

    elif command == 'list_workspace_projects':
        await query.edit_message_text("🔍 جاري البحث عن المشاريع في مساحة العمل...", parse_mode='Markdown')
        projects_raw = run_core_command("list-workspace-projects")
        if "NO_PROJECTS" in projects_raw or not projects_raw:
            await query.edit_message_text("لا توجد مشاريع في مساحة العمل.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("➕ استيراد مشروع", callback_data='import_start')]]))
            return
        projects = sorted(projects_raw.split('\n'))
        keyboard = [[InlineKeyboardButton(p, callback_data=f'project_{p}')] for p in projects]
        keyboard.append([InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data='main_menu')])
        await query.edit_message_text("📂 *مشاريع مساحة العمل:*\n\nاختر مشروعًا.", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

    elif command == 'import_start':
        keyboard = [[InlineKeyboardButton("📁 من Termux", callback_data='import_from_termux')], [InlineKeyboardButton("💾 من الذاكرة", callback_data='import_from_storage')], [InlineKeyboardButton("🔙 رجوع", callback_data='main_menu')]]
        await query.edit_message_text("من أين تريد استيراد المشروع؟", reply_markup=InlineKeyboardMarkup(keyboard))

    elif command == 'import_from_termux':
        dirs_raw = run_core_command("list-termux-dirs")
        dirs = sorted([d for d in dirs_raw.split('\n') if d])
        keyboard = [[InlineKeyboardButton(f"📁 {d}", callback_data=f'import_path_~/{d}')] for d in dirs[:30]]
        keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data='import_start')])
        await query.edit_message_text("اختر مجلدًا من Termux لاستيراده:", reply_markup=InlineKeyboardMarkup(keyboard))

    elif command == 'import_from_storage':
        await query.edit_message_text("أرسل المسار الكامل للمشروع في الذاكرة.\nمثال: `/storage/emulated/0/MyProjects/MyApp`", parse_mode='Markdown')
        context.user_data['state'] = 'awaiting_storage_path'

    elif command.startswith('import_path_'):
        path_to_import = command.replace('import_path_', '', 1)
        await query.edit_message_text(f"⏳ جاري استيراد: `{path_to_import}`...", parse_mode='Markdown')
        project_name = run_core_command(f"import '{path_to_import}'")
        if "ERROR" in project_name:
            await query.edit_message_text(f"❌ فشل:\n`{project_name}`", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data='import_start')]]), parse_mode='Markdown')
        else:
            reply_markup, text = get_project_dashboard_menu(project_name)
            await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    
    elif command.startswith('project_'):
        project_name = command.split('_', 1)[1]
        reply_markup, text = get_project_dashboard_menu(project_name)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

    elif command.startswith('setup_github_'):
        project_name = command.split('_', 1)[1]
        context.user_data['state'] = 'awaiting_repo_url'
        context.user_data['project_for_github'] = project_name
        repo_suggestion = f"https://github.com/{GITHUB_USERNAME or 'YourUsername'}/{project_name}.git"
        await query.edit_message_text(f"🔗 *إعداد GitHub للمشروع: {project_name}*\n\nأرسل رابط HTTPS لمستودع GitHub فارغ.", reply_markup=None, parse_mode='Markdown')

    else: # Handle publish, backup, export
        action, project_name = command.split('_', 1)
        await query.edit_message_text(f"⏳ جاري تنفيذ `{action}`...", parse_mode='Markdown')
        output = run_core_command(f"{action} '{project_name}'")
        if "ERROR" in output: text = f"❌ فشل:\n`{output}`"
        else:
            if action in ['backup', 'export']: await context.bot.send_document(chat_id=query.effective_chat.id, document=open(output, 'rb'))
            text = f"✅ تم تنفيذ `{action}` بنجاح."
        reply_markup, _ = get_project_dashboard_menu(project_name)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = context.user_data.get('state')
    text = update.message.text
    if state == 'awaiting_storage_path':
        await update.message.reply_text(f"⏳ جاري استيراد: `{text}`...", parse_mode='Markdown')
        project_name = run_core_command(f"import '{text}'")
        if "ERROR" in project_name: await update.message.reply_text(f"❌ فشل:\n`{project_name}`", parse_mode='Markdown')
        else:
            reply_markup, menu_text = get_project_dashboard_menu(project_name)
            await update.message.reply_text(menu_text, reply_markup=reply_markup, parse_mode='Markdown')
    elif state == 'awaiting_repo_url':
        project_name = context.user_data.get('project_for_github')
        await update.message.reply_text(f"⏳ جاري ربط `{project_name}`...", parse_mode='Markdown')
        output = run_core_command(f"init-repo '{project_name}' '{text}'")
        await update.message.reply_text(f"✅ *نتيجة الربط:*\n`{output}`", parse_mode='Markdown')
        reply_markup, menu_text = get_project_dashboard_menu(project_name)
        await update.message.reply_text(menu_text, reply_markup=reply_markup, parse_mode='Markdown')
    context.user_data.clear()

def main():
    if not TOKEN: print("❌ CRITICAL: Bot token not found."); return
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    print("🤖 Mukh IDE Bot (v24.0) is now running...")
    app.run_polling()

if __name__ == "__main__":
    main()
