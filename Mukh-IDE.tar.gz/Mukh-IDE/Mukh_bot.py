# Mukh Bot (v20.0 - The Complete Suite)
import logging, os, json, asyncio, subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# --- Basic Setup ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".mukh_ide_config.json")
PROJECTS_DIR = os.path.join(os.path.expanduser("~"), "Mukh-IDE", "projects")

# --- Helper Functions ---
def load_config():
    try:
        with open(CONFIG_FILE) as f: return json.load(f)
    except: return None

def run_core_command(command):
    try:
        # Ensure the command is run from the correct directory context
        full_command = f"bash {os.path.expanduser('~/Mukh-IDE/manus-core')} {command}"
        result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=600, cwd=os.path.expanduser("~/Mukh-IDE"))
        return result.stdout.strip()
    except Exception as e: return f"Error: {e}"

# --- UI Generation Functions ---
def get_main_menu():
    keyboard = [[InlineKeyboardButton("📂 عرض المشاريع", callback_data='list_projects')]]
    text = "🤖 *Mukh IDE (v20.0)*\n\nأهلاً بك! النظام جاهز لإدارة مشاريعك."
    return InlineKeyboardMarkup(keyboard), text

def get_project_dashboard_menu(project_name):
    keyboard = [
        [InlineKeyboardButton("🚀 نشر (Publish)", callback_data=f'publish_{project_name}')],
        [InlineKeyboardButton("📦 تصدير كـ TXT", callback_data=f'export_{project_name}')],
        [InlineKeyboardButton("🛡️ نسخ احتياطي", callback_data=f'backup_{project_name}')],
        [InlineKeyboardButton("🔙 العودة للمشاريع", callback_data='list_projects')]
    ]
    text = f"🛠️ *مشروع: {project_name}*\n\nاختر الإجراء الذي تريد تنفيذه."
    return InlineKeyboardMarkup(keyboard), text

# --- Main Bot Logic ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    command = query.data

    if command == 'list_projects':
        await query.edit_message_text("🔍 جاري البحث عن المشاريع...", parse_mode='Markdown')
        projects_raw = run_core_command("list-projects")
        if "NO_PROJECTS" in projects_raw or not projects_raw:
            await query.edit_message_text("لم يتم العثور على أي مشاريع.\n\nيمكنك إنشاء مجلد مشروع داخل `~/Mukh-IDE/projects` والبدء من جديد.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔄 تحديث", callback_data='list_projects')]]))
            return
        
        projects = sorted([p for p in projects_raw.split('\n') if p])
        keyboard = [[InlineKeyboardButton(p, callback_data=f'project_{p}')] for p in projects]
        keyboard.append([InlineKeyboardButton("🔄 تحديث", callback_data='list_projects')])
        await query.edit_message_text("📂 *المشاريع المتاحة:*\n\nاختر مشروعًا لعرض لوحة التحكم.", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

    elif command.startswith('project_'):
        project_name = command.split('_', 1)[1]
        reply_markup, text = get_project_dashboard_menu(project_name)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

    elif command.startswith('publish_'):
        project_name = command.split('_', 1)[1]
        await query.edit_message_text(f"🚀 جاري نشر: `{project_name}`...", parse_mode='Markdown')
        output = run_core_command(f"publish '{project_name}'")
        reply_markup, _ = get_project_dashboard_menu(project_name)
        await query.edit_message_text(f"✅ *نتيجة النشر:*\n```\n{output[:3500]}\n```", reply_markup=reply_markup, parse_mode='Markdown')

    elif command.startswith('backup_'):
        project_name = command.split('_', 1)[1]
        await query.edit_message_text(f"🛡️ جاري إنشاء نسخة احتياطية: `{project_name}`...", parse_mode='Markdown')
        output = run_core_command(f"backup '{project_name}'")
        if "SUCCESS" in output:
            backup_file_path = output.split(":")[-1].strip()
            await context.bot.send_document(chat_id=query.effective_chat.id, document=open(backup_file_path, 'rb'), caption=f"نسخة احتياطية للمشروع: {project_name}")
        reply_markup, _ = get_project_dashboard_menu(project_name)
        await query.edit_message_text(f"✅ تم الانتهاء من عملية النسخ الاحتياطي.", reply_markup=reply_markup)

    elif command.startswith('export_'):
        project_name = command.split('_', 1)[1]
        await query.edit_message_text(f"📦 جاري تصدير كود المشروع: `{project_name}`...", parse_mode='Markdown')
        output = run_core_command(f"export '{project_name}'")
        if "SUCCESS" in output:
            export_file_path = output.split(":")[-1].strip()
            await context.bot.send_document(chat_id=query.effective_chat.id, document=open(export_file_path, 'rb'), caption=f"ملف كود المشروع: {project_name}")
        reply_markup, _ = get_project_dashboard_menu(project_name)
        await query.edit_message_text(f"✅ تم الانتهاء من عملية التصدير.", reply_markup=reply_markup)

async def send_startup_notification(app: Application):
    config = load_config()
    if not config or not config.get("telegram_chat_id"): return
    chat_id = config.get("telegram_chat_id")
    reply_markup, text = get_main_menu()
    try:
        await app.bot.send_message(chat_id=chat_id, text=text, reply_markup=reply_markup, parse_mode='Markdown')
        print("✅ Startup notification sent successfully.")
    except Exception as e:
        print(f"❌ Failed to send startup notification: {e}")

async def post_init(app: Application):
    # Create project directories if they don't exist
    os.makedirs(PROJECTS_DIR, exist_ok=True)
    asyncio.create_task(send_startup_notification(app))

def main():
    print("--- Starting Mukh IDE Bot (v20.0)...")
    config = load_config()
    if not config or not config.get("telegram_bot_token"):
        print("❌ CRITICAL: Bot token not found. Please run configure.sh first.")
        return
    TOKEN = config.get("telegram_bot_token")
    app = Application.builder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    print("🤖 Mukh IDE Bot is now running...")
    app.run_polling()

if __name__ == "__main__":
    main()
