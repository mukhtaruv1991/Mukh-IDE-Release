# Mukh Bot (v21.0 - Smart Import System)
import logging, os, json, asyncio, subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# --- Basic Setup ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".mukh_ide_config.json")
PROJECTS_DIR = os.path.join(os.path.expanduser("~"), "Mukh-IDE", "projects")

# --- Helper Functions ---
def load_config():
    try:
        with open(CONFIG_FILE) as f: return json.load(f)
    except: return None

def run_core_command(command):
    try:
        full_command = f"bash {os.path.expanduser('~/Mukh-IDE/manus-core')} {command}"
        result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=600, cwd=os.path.expanduser("~/Mukh-IDE"))
        return result.stdout.strip()
    except Exception as e: return f"Error: {e}"

# --- UI Generation Functions ---
def get_main_menu():
    keyboard = [[InlineKeyboardButton("➕ استيراد مشروع جديد", callback_data='import_start')]]
    text = "🤖 *Mukh IDE (v21.0)*\n\nأهلاً بك! لنبدأ باستيراد أول مشروع لك."
    return InlineKeyboardMarkup(keyboard), text

def get_project_dashboard_menu(project_name):
    # This is the full dashboard from the previous version
    keyboard = [
        [InlineKeyboardButton("🚀 نشر (Publish)", callback_data=f'publish_{project_name}')],
        [InlineKeyboardButton("📦 تصدير كـ TXT", callback_data=f'export_{project_name}')],
        [InlineKeyboardButton("🛡️ نسخ احتياطي", callback_data=f'backup_{project_name}')],
        [InlineKeyboardButton("🔙 العودة للقائمة الرئيسية", callback_data='main_menu')]
    ]
    text = f"🛠️ *مشروع: {project_name}*\n\nاختر الإجراء الذي تريد تنفيذه."
    return InlineKeyboardMarkup(keyboard), text

# --- Main Bot Logic ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    command = query.data
    context.user_data['state'] = None # Clear state on button press

    if command == 'main_menu':
        await start(update.effective_message, context)
        return

    elif command == 'import_start':
        keyboard = [
            [InlineKeyboardButton("📁 من Termux", callback_data='import_from_termux')],
            [InlineKeyboardButton("💾 من الذاكرة الداخلية", callback_data='import_from_storage')],
            [InlineKeyboardButton("🔙 رجوع", callback_data='main_menu')]
        ]
        await query.edit_message_text("من أين تريد استيراد المشروع؟", reply_markup=InlineKeyboardMarkup(keyboard))

    elif command == 'import_from_termux':
        await query.edit_message_text("🔍 جاري البحث عن المجلدات في Termux...", parse_mode='Markdown')
        dirs_raw = run_core_command("list-termux-dirs")
        dirs = sorted([d for d in dirs_raw.split('\n') if d and d not in ['Mukh-IDE', 'release_repo', 'final_build']])
        keyboard = [[InlineKeyboardButton(f"📁 {d}", callback_data=f'import_path_~/{d}')] for d in dirs[:20]] # Limit to 20
        keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data='import_start')])
        await query.edit_message_text("اختر مجلدًا من Termux لاستيراده:", reply_markup=InlineKeyboardMarkup(keyboard))

    elif command == 'import_from_storage':
        await query.edit_message_text("الرجاء إرسال المسار الكامل للمشروع في الذاكرة الداخلية.\n\nمثال: `/storage/emulated/0/MyProjects/MyApp`", parse_mode='Markdown')
        context.user_data['state'] = 'awaiting_storage_path'

    elif command.startswith('import_path_'):
        path_to_import = command.replace('import_path_', '', 1)
        await query.edit_message_text(f"⏳ جاري استيراد: `{path_to_import}`...", parse_mode='Markdown')
        project_name = run_core_command(f"import '{path_to_import}'")
        if "ERROR" in project_name:
            await query.edit_message_text(f"❌ فشل الاستيراد:\n`{project_name}`", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data='import_start')]]), parse_mode='Markdown')
        else:
            reply_markup, text = get_project_dashboard_menu(project_name)
            await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    
    # Add handlers for publish, backup, export here, similar to the previous version
    elif command.startswith('publish_') or command.startswith('backup_') or command.startswith('export_'):
        action, project_name = command.split('_', 1)
        await query.edit_message_text(f"⏳ جاري تنفيذ `{action}` على مشروع `{project_name}`...", parse_mode='Markdown')
        # We need the full logic for these actions from the previous version's core
        # For now, this is a placeholder
        await query.edit_message_text(f"تم تنفيذ `{action}` بنجاح (هذه رسالة مؤقتة).", parse_mode='Markdown')


async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get('state') == 'awaiting_storage_path':
        path_to_import = update.message.text
        await update.message.reply_text(f"⏳ جاري استيراد: `{path_to_import}`...", parse_mode='Markdown')
        project_name = run_core_command(f"import '{path_to_import}'")
        if "ERROR" in project_name:
            await update.message.reply_text(f"❌ فشل الاستيراد:\n`{project_name}`", parse_mode='Markdown')
        else:
            reply_markup, text = get_project_dashboard_menu(project_name)
            await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')
        context.user_data['state'] = None


async def post_init(app: Application):
    os.makedirs(PROJECTS_DIR, exist_ok=True)
    # No startup notification needed, user interaction is the start

def main():
    print("--- Starting Mukh IDE Bot (v21.0)...")
    config = load_config()
    if not config or not config.get("telegram_bot_token"):
        print("❌ CRITICAL: Bot token not found.")
        return
    TOKEN = config.get("telegram_bot_token")
    app = Application.builder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    print("🤖 Mukh IDE Bot is now running...")
    app.run_polling()

if __name__ == "__main__":
    main()
