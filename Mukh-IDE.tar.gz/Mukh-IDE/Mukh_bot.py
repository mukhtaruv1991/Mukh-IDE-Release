# Mukh Bot (v23.0 - GitHub Setup)
import logging, os, json, asyncio, subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# --- Setup ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
HOME_DIR = os.path.expanduser("~")
TOKEN, CHAT_ID, GITHUB_USERNAME = None, None, None
try:
    with open(os.path.join(HOME_DIR, ".manus_global_config.json")) as f:
        config = json.load(f)
    TOKEN = config.get("telegram_bot_token")
    CHAT_ID = config.get("telegram_chat_id")
    GITHUB_USERNAME = config.get("github_username")
except Exception as e:
    logging.error(f"Config Error: {e}")

# --- Helper Functions ---
def run_core_command(command):
    try:
        full_command = f"bash {os.path.expanduser('~/Mukh-IDE/manus-core')} {command}"
        result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=600)
        return result.stdout.strip()
    except Exception as e: return f"Error: {e}"

# --- UI Generation Functions ---
def get_main_menu():
    keyboard = [[InlineKeyboardButton("📂 عرض المشاريع", callback_data='view_projects')]]
    return InlineKeyboardMarkup(keyboard), "🤖 *Mukh IDE (v23.0)*\n\nاختر إجراءً للبدء."

def get_projects_menu():
    projects_raw = run_core_command("list-projects")
    if not projects_raw: return None, "لم يتم العثور على مشاريع."
    projects = sorted(projects_raw.split('\n'))
    keyboard = [[InlineKeyboardButton(p, callback_data=f'project_{p}')] for p in projects[:40]]
    keyboard.append([InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data='main_menu')])
    return InlineKeyboardMarkup(keyboard), f"📂 *المشاريع* (تم العثور على {len(projects)})\n\nاختر مشروعًا:"

def get_project_dashboard_menu(project_name):
    project_path = os.path.join(HOME_DIR, project_name)
    is_git_repo = os.path.isdir(os.path.join(project_path, ".git"))
    
    keyboard = []
    if is_git_repo:
        keyboard.append([InlineKeyboardButton("🚀 نشر (Publish)", callback_data=f'publish_{project_name}')])
    else:
        keyboard.append([InlineKeyboardButton("🔗 إعداد GitHub (Setup GitHub)", callback_data=f'setup_github_{project_name}')])
    
    keyboard.extend([
        [InlineKeyboardButton("📦 تصدير كـ TXT", callback_data=f'export_{project_name}')],
        [InlineKeyboardButton("🛡️ نسخ احتياطي", callback_data=f'backup_{project_name}')],
        [InlineKeyboardButton("📂 تصفح الملفات", callback_data=f'browse_{project_name}_.')],
        [InlineKeyboardButton("🔙 العودة للمشاريع", callback_data='view_projects')]
    ])
    
    text = f"🛠️ *مشروع: {project_name}*\n\n"
    if not is_git_repo:
        text += "⚠️ هذا المشروع غير مربوط بـ GitHub. اضغط 'إعداد GitHub' للبدء.\n\n"
    text += "اختر الإجراء الذي تريد تنفيذه."
    return InlineKeyboardMarkup(keyboard), text

# (Browse menu remains the same)
def get_browse_menu(project_name, path):
    full_path = os.path.join(HOME_DIR, project_name, path)
    try: items = os.listdir(full_path)
    except: return None, "خطأ في التصفح"
    dirs = sorted([d for d in items if os.path.isdir(os.path.join(full_path, d))])
    files = sorted([f for f in items if os.path.isfile(os.path.join(full_path, f))])
    keyboard = []
    for d in dirs: keyboard.append([InlineKeyboardButton(f"📁 {d}", callback_data=f'browse_{project_name}_{os.path.join(path, d)}')])
    for f in files: keyboard.append([InlineKeyboardButton(f"📄 {f}", callback_data=f'cat_{project_name}_{os.path.join(path, f)}')])
    if path == '.': keyboard.append([InlineKeyboardButton("🔙 إلى لوحة التحكم", callback_data=f'project_{project_name}')])
    else: keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data=f'browse_{project_name}_{os.path.dirname(path)}')])
    return InlineKeyboardMarkup(keyboard), f"🧭 *تصفح: {project_name}/{path}*"

# --- Main Bot Logic ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    command = query.data
    context.user_data.pop('state', None) # Clear state

    if command == 'main_menu':
        reply_markup, text = get_main_menu()
    elif command == 'view_projects':
        reply_markup, text = get_projects_menu()
    elif command.startswith('project_'):
        project_name = command.split('_', 1)[1]
        context.user_data['current_project'] = project_name
        reply_markup, text = get_project_dashboard_menu(project_name)
    elif command.startswith('setup_github_'):
        project_name = command.split('_', 1)[1]
        context.user_data['state'] = 'awaiting_repo_url'
        context.user_data['project_for_github'] = project_name
        repo_suggestion = f"https://github.com/{GITHUB_USERNAME or 'YourUsername'}/{project_name}.git"
        text = f"🔗 *إعداد GitHub للمشروع: {project_name}*\n\n"
        text += "1. اذهب إلى GitHub وأنشئ مستودعًا جديدًا (فارغًا).\n"
        text += f"2. انسخ رابط الـ HTTPS الخاص به وأرسله هنا.\n\n"
        text += f"مثال:\n`{repo_suggestion}`"
        reply_markup = None # No buttons, just wait for text
    # (Other handlers like browse, cat, publish, backup, export are similar to v22)
    else:
        # This is a simplified handler for all core actions
        parts = command.split('_', 1)
        action, project_name = parts[0], parts[1]
        
        if action in ['publish', 'backup', 'export']:
            await query.edit_message_text(f"⏳ جاري تنفيذ `{action}`...", parse_mode='Markdown')
            output = run_core_command(f"{action} '{project_name}'")
            if "ERROR" in output:
                text = f"❌ فشل:\n`{output}`"
            else:
                if action in ['backup', 'export']:
                    await context.bot.send_document(chat_id=query.effective_chat.id, document=open(output, 'rb'))
                text = f"✅ تم تنفيذ `{action}` بنجاح."
            reply_markup, _ = get_project_dashboard_menu(project_name)
        else: # Fallback for browse/cat which need separate logic
            _, project_name, path = command.split('_', 2)
            if _ == 'browse':
                reply_markup, text = get_browse_menu(project_name, path)
            elif _ == 'cat':
                # Simplified cat logic for brevity
                text = "File content would be shown here."
                reply_markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 رجوع", callback_data=f'browse_{project_name}_{os.path.dirname(path)}')]])

    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get('state') == 'awaiting_repo_url':
        repo_url = update.message.text
        project_name = context.user_data.get('project_for_github')
        await update.message.reply_text(f"⏳ جاري ربط المشروع `{project_name}` بالمستودع...", parse_mode='Markdown')
        
        output = run_core_command(f"init-repo '{project_name}' '{repo_url}'")
        
        await update.message.reply_text(f"✅ *نتيجة الربط:*\n```\n{output}\n```", parse_mode='Markdown')
        
        context.user_data.clear()
        reply_markup, text = get_project_dashboard_menu(project_name)
        await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

def main():
    if not TOKEN: print("❌ CRITICAL: Bot token not found."); return
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    print("🤖 Mukh IDE Bot (v23.0) is now running...")
    app.run_polling()

if __name__ == "__main__":
    main()
