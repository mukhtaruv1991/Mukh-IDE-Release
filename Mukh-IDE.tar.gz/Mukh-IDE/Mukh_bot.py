# Mukh Bot (v22.0 - The Final Merge)
import logging, os, json, asyncio, subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# --- Setup (from old bot) ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
HOME_DIR = os.path.expanduser("~")
TOKEN, CHAT_ID = None, None
try:
    with open(os.path.join(HOME_DIR, ".manus_global_config.json")) as f:
        config = json.load(f)
    TOKEN = config.get("telegram_bot_token")
    CHAT_ID = config.get("telegram_chat_id")
except Exception as e:
    logging.error(f"Config Error: {e}")

# --- Helper Functions ---
def run_core_command(command):
    try:
        full_command = f"bash {os.path.expanduser('~/Mukh-IDE/manus-core')} {command}"
        result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=600)
        return result.stdout.strip()
    except Exception as e: return f"Error: {e}"

# --- UI Generation Functions (from old bot, adapted for core) ---
def get_main_menu():
    keyboard = [[InlineKeyboardButton("📂 عرض المشاريع", callback_data='view_projects')]]
    return InlineKeyboardMarkup(keyboard), "🤖 *Mukh IDE (v22.0)*\n\nاختر إجراءً للبدء."

def get_projects_menu():
    projects_raw = run_core_command("list-projects")
    if not projects_raw:
        return None, "لم يتم العثور على مشاريع."
    projects = sorted(projects_raw.split('\n'))
    keyboard = [[InlineKeyboardButton(p, callback_data=f'project_{p}')] for p in projects[:40]]
    keyboard.append([InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data='main_menu')])
    return InlineKeyboardMarkup(keyboard), f"📂 *المشاريع* (تم العثور على {len(projects)})\n\nاختر مشروعًا:"

def get_project_dashboard_menu(project_name):
    keyboard = [
        [InlineKeyboardButton("🚀 نشر (Publish)", callback_data=f'publish_{project_name}')],
        [InlineKeyboardButton("📦 تصدير كـ TXT", callback_data=f'export_{project_name}')],
        [InlineKeyboardButton("🛡️ نسخ احتياطي", callback_data=f'backup_{project_name}')],
        [InlineKeyboardButton("📂 تصفح الملفات", callback_data=f'browse_{project_name}_.')],
        [InlineKeyboardButton("🔙 العودة للمشاريع", callback_data='view_projects')]
    ]
    return InlineKeyboardMarkup(keyboard), f"🛠️ *مشروع: {project_name}*\n\nاختر الإجراء الذي تريد تنفيذه."

def get_browse_menu(project_name, path):
    full_path = os.path.join(HOME_DIR, project_name, path)
    try:
        items = os.listdir(full_path)
    except Exception as e:
        return None, f"خطأ في التصفح: {e}"
    
    dirs = sorted([d for d in items if os.path.isdir(os.path.join(full_path, d))])
    files = sorted([f for f in items if os.path.isfile(os.path.join(full_path, f))])
    
    keyboard = []
    for d in dirs: keyboard.append([InlineKeyboardButton(f"📁 {d}", callback_data=f'browse_{project_name}_{os.path.join(path, d)}')])
    for f in files: keyboard.append([InlineKeyboardButton(f"📄 {f}", callback_data=f'cat_{project_name}_{os.path.join(path, f)}')])
    
    if path == '.':
        keyboard.append([InlineKeyboardButton("🔙 إلى لوحة التحكم", callback_data=f'project_{project_name}')])
    else:
        parent_path = os.path.dirname(path)
        keyboard.append([InlineKeyboardButton("🔙 رجوع", callback_data=f'browse_{project_name}_{parent_path}')])
        
    return InlineKeyboardMarkup(keyboard), f"🧭 *تصفح: {project_name}/{path}*"

# --- Main Bot Logic ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    command = query.data

    if command == 'main_menu':
        reply_markup, text = get_main_menu()
    elif command == 'view_projects':
        reply_markup, text = get_projects_menu()
    elif command.startswith('project_'):
        project_name = command.split('_', 1)[1]
        reply_markup, text = get_project_dashboard_menu(project_name)
    elif command.startswith('browse_'):
        _, project_name, path = command.split('_', 2)
        reply_markup, text = get_browse_menu(project_name, path)
    elif command.startswith('cat_'):
        _, project_name, path = command.split('_', 2)
        full_path = os.path.join(HOME_DIR, project_name, path)
        await query.edit_message_text(f"⏳ جاري قراءة الملف: `{path}`...", parse_mode='Markdown')
        try:
            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f: content = f.read()
            parent_path = os.path.dirname(path)
            kb = [[InlineKeyboardButton("🔙 رجوع", callback_data=f'browse_{project_name}_{parent_path}')]]
            text = f"📄 *محتوى الملف: {os.path.basename(path)}*\n\n```\n{content[:3900]}\n```"
            reply_markup = InlineKeyboardMarkup(kb)
        except Exception as e:
            text = f"❌ خطأ في قراءة الملف: {e}"
            reply_markup = None
    elif command.startswith('publish_') or command.startswith('backup_') or command.startswith('export_'):
        action, project_name = command.split('_', 1)
        await query.edit_message_text(f"⏳ جاري تنفيذ `{action}` على مشروع `{project_name}`...", parse_mode='Markdown')
        output = run_core_command(f"{action} '{project_name}'")
        if "Error" in output:
            text = f"❌ فشل:\n`{output}`"
        else:
            if action in ['backup', 'export']:
                await context.bot.send_document(chat_id=query.effective_chat.id, document=open(output, 'rb'), caption=f"ملف ناتج عن عملية {action}")
            text = f"✅ تم تنفيذ `{action}` بنجاح."
        reply_markup, _ = get_project_dashboard_menu(project_name)
    else:
        reply_markup, text = get_main_menu()

    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

def main():
    if not TOKEN:
        print("❌ CRITICAL: Bot token not found in ~/.manus_global_config.json")
        return
    
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    print("🤖 Mukh IDE Bot (v22.0) is now running...")
    app.run_polling()

if __name__ == "__main__":
    main()
