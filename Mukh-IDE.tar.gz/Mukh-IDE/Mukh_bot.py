# Mukh Bot (v11.0 - Smart Startup)
import logging, os, json, asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

# --- Basic Setup ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".mukh_ide_config.json")

# --- Helper Functions ---
def load_config():
    """Loads the configuration from the JSON file."""
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None

def get_main_menu():
    """Generates the main menu keyboard and text."""
    keyboard = [
        [InlineKeyboardButton("➕ مشروع جديد", callback_data='add_project')],
        [InlineKeyboardButton("📂 عرض المشاريع", callback_data='list_projects')]
    ]
    text = "🤖 *Mukh IDE (v11.0)*\n\nأهلاً بك! النظام جاهز لاستقبال أوامرك."
    return InlineKeyboardMarkup(keyboard), text

# --- Main Bot Logic ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /start command."""
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def send_startup_notification(app: Application):
    """Sends a notification message when the bot starts."""
    config = load_config()
    if not config or not config.get("telegram_chat_id"):
        print("⚠️ Could not send startup notification: Chat ID not found in config.")
        return
    
    chat_id = config.get("telegram_chat_id")
    reply_markup, text = get_main_menu()
    
    try:
        await app.bot.send_message(
            chat_id=chat_id,
            text=text,
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        print("✅ Startup notification sent successfully.")
    except Exception as e:
        print(f"❌ Failed to send startup notification: {e}")

async def post_init(app: Application):
    """A function that runs after the bot is initialized."""
    await send_startup_notification(app)

def main():
    """The main function to run the bot."""
    print("--- Starting Mukh IDE Bot (v11.0)...")
    config = load_config()
    if not config or not config.get("telegram_bot_token"):
        print("❌ CRITICAL: Bot token not found in ~/.mukh_ide_config.json")
        print("Please run the configuration script first (bash ~/Mukh-IDE/configure.sh).")
        return

    TOKEN = config.get("telegram_bot_token")
    
    # Use the post_init feature to run a function after setup
    app = Application.builder().token(TOKEN).post_init(post_init).build()

    # Add command handlers
    app.add_handler(CommandHandler("start", start))
    # (We will add more handlers for the buttons later)

    print("🤖 Mukh IDE Bot is now running and polling for updates...")
    app.run_polling()

if __name__ == "__main__":
    main()
