# Mukh Bot (v40.0 - The God-Tier System)
import logging, os, json, subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
HOME_DIR = os.path.expanduser("~")
TOKEN, CHAT_ID, GITHUB_USERNAME = None, None, None
try:
    with open(os.path.join(HOME_DIR, ".manus_global_config.json")) as f: config = json.load(f)
    TOKEN = config.get("telegram_bot_token"); CHAT_ID = config.get("telegram_chat_id"); GITHUB_USERNAME = config.get("github_username")
except: pass

def run_core_command(command):
    try:
        full_command = f"bash {os.path.expanduser('~/Mukh-IDE/manus-core')} {command}"
        result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=600)
        return result.stdout.strip()
    except Exception as e: return f"Error: {e}"

def get_main_menu():
    keyboard = [[InlineKeyboardButton("📂 عرض المشاريع", callback_data='list_projects')]]
    return InlineKeyboardMarkup(keyboard), "🤖 *Mukh IDE (v40.0)*\n\nأرسل /start لبدء التفاعل."

async def get_project_dashboard(project_name):
    status_json = run_core_command(f"check-status '{project_name}'")
    status = json.loads(status_json)
    keyboard = []
    if not status.get('github_auth_ok'):
        keyboard.append([InlineKeyboardButton("⚠️ إعداد GitHub CLI", callback_data='setup_gh_cli')])
    elif not status.get('is_git_repo') or not status.get('has_remote'):
        keyboard.append([InlineKeyboardButton("🔗 إعداد GitHub", callback_data=f'setup_github_{project_name}')])
    else:
        if not status.get('has_workflow'):
            keyboard.append([InlineKeyboardButton("✨ تجهيز Workflow", callback_data=f'ensure_workflow_{project_name}')])
        keyboard.append([InlineKeyboardButton("🚀 نشر", callback_data=f'publish_{project_name}')])
    
    keyboard.extend([
        [InlineKeyboardButton("📦 تصدير", callback_data=f'export_{project_name}'), InlineKeyboardButton("🛡️ نسخ احتياطي", callback_data=f'backup_{project_name}')],
        [InlineKeyboardButton("🔙 العودة للمشاريع", callback_data='list_projects')]
    ])
    return InlineKeyboardMarkup(keyboard), f"🛠️ *مشروع: {project_name}*\n\nاختر الإجراء."

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer(); command = query.data
    context.user_data.clear()

    if command == 'list_projects':
        projects_raw = run_core_command("list-projects")
        projects = projects_raw.split('\n') if projects_raw else []
        keyboard = [[InlineKeyboardButton(p, callback_data=f'project_{p}')] for p in projects[:30]]
        keyboard.append([InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data='main_menu')])
        await query.edit_message_text("📂 *المشاريع:*\n\nاختر مشروعًا.", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    elif command.startswith('project_'):
        project_name = command.split('_', 1)[1]
        reply_markup, text = await get_project_dashboard(project_name)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    elif command.startswith('setup_github_'):
        project_name = command.split('_', 1)[1]
        context.user_data['state'] = 'awaiting_repo_name'
        context.user_data['project_for_github'] = project_name
        await query.edit_message_text(f"🔗 *إعداد GitHub للمشروع: {project_name}*\n\nأرسل اسمًا للمستودع الجديد (e.g., my-cool-app).", parse_mode='Markdown')
    elif command.startswith('set_visibility_'):
        project_name, repo_name, visibility = command.split('_', 2)
        await query.edit_message_text(f"⏳ جاري إنشاء مستودع `{repo_name}` وربطه...", parse_mode='Markdown')
        output = run_core_command(f"setup-github '{project_name}' '{repo_name}' '{visibility}'")
        reply_markup, text = await get_project_dashboard(project_name)
        await query.edit_message_text(f"✅ *النتيجة:*\n`{output}`\n\n{text}", reply_markup=reply_markup, parse_mode='Markdown')
    elif command.startswith('ensure_workflow_'):
        project_name = command.split('_', 1)[1]
        await query.edit_message_text(f"⏳ جاري التحقق من Workflow...", parse_mode='Markdown')
        run_core_command(f"ensure-workflow '{project_name}'")
        reply_markup, text = await get_project_dashboard(project_name)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')
    else: # publish, backup, export
        action, project_name = command.split('_', 1)
        await query.edit_message_text(f"⏳ جاري تنفيذ `{action}`...", parse_mode='Markdown')
        output = run_core_command(f"{action} '{project_name}'")
        if "ERROR" in output: text = f"❌ فشل:\n`{output}`"
        else:
            if action in ['backup', 'export']: await context.bot.send_document(chat_id=query.effective_chat.id, document=open(output, 'rb'))
            text = f"✅ تم تنفيذ `{action}` بنجاح."
        reply_markup, _ = await get_project_dashboard(project_name)
        await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = context.user_data.get('state')
    text = update.message.text.strip()
    
    if "❌" in text and "failing" in text: # Basic error detection
        project_name_match = re.search(r"Workflow '.*' for branch 'main' failed for repository '.*/(.*)'", text)
        if project_name_match:
            project_name = project_name_match.group(1)
            await update.message.reply_text(f"⚠️ تم اكتشاف خطأ في بناء مشروع `{project_name}`. جاري إنشاء ملف السياق...", parse_mode='Markdown')
            context_file = run_core_command(f"create-error-context '{project_name}' \"{text}\"")
            await update.message.reply_text("✅ ملف السياق جاهز. أرسله إلى Gemini واطلب أمر إصلاح مباشر، ثم الصق الأمر هنا.", parse_mode='Markdown')
            await context.bot.send_document(chat_id=update.effective_chat.id, document=open(context_file, 'rb'))
            context.user_data['state'] = 'awaiting_fix_command'
            context.user_data['project_for_fix'] = project_name
        return

    if state == 'awaiting_repo_name':
        project_name = context.user_data.get('project_for_github')
        repo_name = text
        kb = [[InlineKeyboardButton("🔒 خاص", callback_data=f'set_visibility_{project_name}_{repo_name}_private'), InlineKeyboardButton("🌍 عام", callback_data=f'set_visibility_{project_name}_{repo_name}_public')]]
        await update.message.reply_text("اختر رؤية المستودع:", reply_markup=InlineKeyboardMarkup(kb))
    elif state == 'awaiting_fix_command':
        project_name = context.user_data.get('project_for_fix')
        await update.message.reply_text(f"🛡️ جاري أخذ نسخة احتياطية وتطبيق الإصلاح على `{project_name}`...", parse_mode='Markdown')
        output = run_core_command(f"apply-fix '{project_name}' \"{text}\"")
        await update.message.reply_text(f"✅ *نتيجة تطبيق الإصلاح:*\n```\n{output}\n```\n\nيمكنك الآن محاولة النشر مرة أخرى.", parse_mode='Markdown')
    context.user_data.clear()

def main():
    if not TOKEN: print("❌ CRITICAL: Bot token not found."); return
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start_command)); app.add_handler(CallbackQueryHandler(button_handler)); app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    print("🤖 Mukh IDE Bot (v40.0) is now running..."); print("➡️ Send /start in your Telegram chat to begin."); app.run_polling()
if __name__ == "__main__": main()
