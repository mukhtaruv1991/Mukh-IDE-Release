# Mukh Bot (v28.0 - The Correct Async Solution)
import logging, os, json, asyncio, subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.constants import ParseMode

# --- Setup ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
HOME_DIR = os.path.expanduser("~")
TOKEN, CHAT_ID, GITHUB_USERNAME = None, None, None
try:
    with open(os.path.join(HOME_DIR, ".manus_global_config.json")) as f:
        config = json.load(f)
    TOKEN = config.get("telegram_bot_token")
    CHAT_ID = config.get("telegram_chat_id")
    GITHUB_USERNAME = config.get("github_username")
except: pass

# --- Helper Functions ---
def run_core_command(command):
    try:
        full_command = f"bash {os.path.expanduser('~/Mukh-IDE/manus-core')} {command}"
        result = subprocess.run(full_command, shell=True, capture_output=True, text=True, timeout=600)
        return result.stdout.strip()
    except Exception as e: return f"Error: {e}"

# --- UI Generation ---
def get_main_menu():
    keyboard = [
        [InlineKeyboardButton("📁 مشاريع Termux", callback_data='list_termux_projects_by-name-asc')],
        [InlineKeyboardButton("💾 استيراد من الذاكرة", callback_data='import_from_storage')]
    ]
    return InlineKeyboardMarkup(keyboard), "🤖 *Mukh IDE (v28.0)*\n\nأهلاً بك! النظام جاهز ويعمل."

# (Other UI functions remain the same)
def get_termux_projects_menu(sort_order="by-name-asc"):
    projects_raw = run_core_command(f"list-projects {sort_order}")
    projects = projects_raw.split('\n') if projects_raw else []
    keyboard = []; message_text = "📁 *مشاريع Termux:*\n\n"
    if not projects: message_text += "لم يتم العثور على مشاريع."
    else:
        keyboard.extend([[InlineKeyboardButton(p, callback_data=f'project_{p}')] for p in projects[:30]])
        message_text += "اختر مشروعًا."
    sort_keyboard = [ InlineKeyboardButton("⬆️", callback_data='list_termux_projects_by-name-asc'), InlineKeyboardButton("⬇️", callback_data='list_termux_projects_by-name-desc') ]
    keyboard.append(sort_keyboard)
    keyboard.append([InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data='main_menu')])
    return InlineKeyboardMarkup(keyboard), message_text

def get_project_dashboard_menu(project_name):
    project_path = os.path.join(HOME_DIR, project_name)
    is_git_repo = os.path.isdir(os.path.join(project_path, ".git"))
    keyboard = []
    if is_git_repo: keyboard.append([InlineKeyboardButton("🚀 نشر", callback_data=f'publish_{project_name}')])
    else: keyboard.append([InlineKeyboardButton("🔗 إعداد GitHub", callback_data=f'setup_github_{project_name}')])
    keyboard.extend([
        [InlineKeyboardButton("📦 تصدير", callback_data=f'export_{project_name}'), InlineKeyboardButton("🛡️ نسخ احتياطي", callback_data=f'backup_{project_name}')],
        [InlineKeyboardButton("🔙 العودة للمشاريع", callback_data='list_termux_projects_by-name-asc')]
    ])
    return InlineKeyboardMarkup(keyboard), f"🛠️ *مشروع: {project_name}*\n\nاختر الإجراء."

# --- Main Bot Logic ---
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    reply_markup, text = get_main_menu()
    await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='Markdown')

# THE FIX: This is the new callback function for the startup job
async def send_startup_notification(context: ContextTypes.DEFAULT_TYPE):
    """Sends the startup message to the user."""
    try:
        reply_markup, text = get_main_menu()
        await context.bot.send_message(chat_id=CHAT_ID, text=text, reply_markup=reply_markup, parse_mode='Markdown')
        print("✅ Startup notification sent successfully.")
    except Exception as e:
        print(f"⚠️ Could not send startup notification: {e}")

# (Button and text handlers remain the same)
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer(); command = query.data
    context.user_data.pop('state', None)
    if command == 'main_menu': await start_command(update.effective_message, context); return
    elif command.startswith('list_termux_projects_'):
        sort_order = command.replace('list_termux_projects_', '', 1)
        reply_markup, text = get_termux_projects_menu(sort_order)
    elif command == 'import_from_storage':
        text = "أرسل المسار الكامل للمشروع في الذاكرة."
        context.user_data['state'] = 'awaiting_storage_path'; reply_markup = None
    elif command.startswith('project_'):
        project_name = command.split('_', 1)[1]
        reply_markup, text = get_project_dashboard_menu(project_name)
    elif command.startswith('confirm_overwrite_'):
        path_to_import = command.replace('confirm_overwrite_', '', 1)
        text = f"⏳ جاري استيراد: `{path_to_import}`..."
        run_core_command(f"import-overwrite '{path_to_import}'")
        project_name = os.path.basename(path_to_import)
        reply_markup, text = get_project_dashboard_menu(project_name)
    elif command.startswith('setup_github_'):
        project_name = command.split('_', 1)[1]
        context.user_data['state'] = 'awaiting_repo_url'; context.user_data['project_for_github'] = project_name
        text = f"🔗 *إعداد GitHub للمشروع: {project_name}*\n\nأرسل رابط HTTPS لمستودع GitHub فارغ."; reply_markup = None
    else:
        action, project_name = command.split('_', 1)
        text = f"⏳ جاري تنفيذ `{action}`..."
        output = run_core_command(f"{action} '{project_name}'")
        if "ERROR" in output: text = f"❌ فشل:\n`{output}`"
        else:
            if action in ['backup', 'export']: await context.bot.send_document(chat_id=query.effective_chat.id, document=open(output, 'rb'))
            text = f"✅ تم تنفيذ `{action}` بنجاح."
        reply_markup, _ = get_project_dashboard_menu(project_name)
    await query.edit_message_text(text, reply_markup=reply_markup, parse_mode='Markdown')

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = context.user_data.get('state'); text = update.message.text
    if state == 'awaiting_storage_path':
        await update.message.reply_text(f"⏳ جاري استيراد: `{text}`...", parse_mode='Markdown')
        output = run_core_command(f"import-from-storage '{text}'")
        if "CONFIRM_OVERWRITE" in output:
            project_name = os.path.basename(text)
            kb = [[InlineKeyboardButton("نعم", callback_data=f'confirm_overwrite_{text}')], [InlineKeyboardButton("لا", callback_data='main_menu')]]
            await update.message.reply_text(f"⚠️ المشروع '{project_name}' موجود. هل تريد الكتابة فوقه؟", reply_markup=InlineKeyboardMarkup(kb))
        elif "SUCCESS" in output:
            project_name = os.path.basename(text)
            reply_markup, menu_text = get_project_dashboard_menu(project_name)
            await update.message.reply_text(menu_text, reply_markup=reply_markup, parse_mode='Markdown')
        else: await update.message.reply_text(f"❌ فشل:\n`{output}`", parse_mode='Markdown')
    elif state == 'awaiting_repo_url':
        project_name = context.user_data.get('project_for_github')
        await update.message.reply_text(f"⏳ جاري ربط `{project_name}`...", parse_mode='Markdown')
        output = run_core_command(f"init-repo '{project_name}' '{text}'")
        await update.message.reply_text(f"✅ *نتيجة الربط:*\n`{output}`", parse_mode='Markdown')
        reply_markup, menu_text = get_project_dashboard_menu(project_name)
        await update.message.reply_text(menu_text, reply_markup=reply_markup, parse_mode='Markdown')
    context.user_data.clear()

# THE FIX: This is the new, correct main function
def main():
    if not TOKEN or not CHAT_ID:
        print("❌ CRITICAL: Bot token or Chat ID not found.")
        return
    
    # 1. Build the application
    app = Application.builder().token(TOKEN).build()
    
    # 2. Add all handlers
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))

    # 3. Schedule the startup notification job
    # This tells the bot: "As soon as you start, run this function once."
    app.job_queue.run_once(send_startup_notification, 1) # 1 second delay

    # 4. Start the bot
    print("🤖 Mukh IDE Bot (v28.0) is now running...")
    app.run_polling()

if __name__ == "__main__":
    main()
